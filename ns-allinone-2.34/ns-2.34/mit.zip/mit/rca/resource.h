/*************************************************************************
 *
 * This code was developed as part of the MIT SPIN project. (June, 1999)
 *
 *************************************************************************/


#ifndef resource_h
#define resource_h

#include <object.h>

class Resource ;

class Resource : public TclObject {
 public:
  Resource();
  ~Resource();
};

#endif
